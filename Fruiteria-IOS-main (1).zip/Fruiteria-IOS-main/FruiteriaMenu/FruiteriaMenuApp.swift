//
//  FruiteriaMenuApp.swift
//  FruiteriaMenu
//
//  Created by Cody Burgess on 9/26/23.
//

import SwiftUI

@main
struct FruiteriaMenuApp: App {
    var body: some Scene {
        WindowGroup {
            HomePage()
        }
    }
}
