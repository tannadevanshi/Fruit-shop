//
//  AccountView.swift
//  FruiteriaMenu
//
//  Created by Cody Burgess on 9/26/23.
//

import SwiftUI

struct AccountView: View {
    var body: some View {
        NavigationView {
            Text("Account View")
                .navigationTitle("🧾 Account View")
        }
    }
}

#Preview {
    AccountView()
}
