//
//  OrderView.swift
//  FruiteriaMenu
//
//  Created by Cody Burgess on 9/26/23.
//

import SwiftUI

struct OrderView: View {
    var body: some View {
        NavigationView {
            Text("Orders View")
                .navigationTitle("🛒 Orders")
        }
    }
}

#Preview {
    OrderView()
}
